jQuery(function ($) {
    const $confirmBox = $('#dcp-confirm');
    const $confirmBtn = $('#dcp-confirm-delete');

    $('#dcp-delete-btn').on('click', function () {
        $confirmBox.toggleClass('hidden');
    });

    $('#dcp-cancel').on('click', function () {
        $confirmBox.addClass('hidden');
    });

    $confirmBtn.on('click', function () {
        $confirmBtn.prop('disabled', true).text('Deleting...');

        $.post(DCP.ajax, {
            action: 'dcp_delete_post',
            nonce: DCP.nonce,
            post_id: DCP.post_id
        }).done(function (res) {
            if (res.success) {
                window.location.href = DCP.redirect;
            } else {
                alert(res.data || 'Delete failed');
                $confirmBtn.prop('disabled', false).text('Confirm');
            }
        });
    });
});
