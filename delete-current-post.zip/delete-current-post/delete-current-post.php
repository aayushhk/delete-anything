<?php
/**
 * Plugin Name: Delete Current Post (Enhanced)
 * Description: Tailwind delete button shortcode with confirmation, permissions, trash support, and archive redirect.
 */

if (!defined('ABSPATH')) exit;

add_shortcode('delete_current_post', function () {
    if (!is_singular()) return '';
    if (!is_user_logged_in()) return '';

    global $post;
    if (!$post) return '';

    $user_id = get_current_user_id();

    // Permission: author OR admin
    if (
        (int) $post->post_author !== $user_id &&
        !current_user_can('delete_others_posts')
    ) {
        return '';
    }

    // Determine archive URL
    $post_type = get_post_type($post);
    $archive_url = get_post_type_archive_link($post_type);
    if (!$archive_url) {
        $archive_url = home_url();
    }

    wp_enqueue_script(
        'dcp-js',
        plugin_dir_url(__FILE__) . 'delete.js',
        ['jquery'],
        null,
        true
    );

    wp_localize_script('dcp-js', 'DCP', [
        'ajax'     => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('dcp_delete'),
        'post_id'  => $post->ID,
        'redirect' => esc_url($archive_url)
    ]);

    return <<<HTML
<div class="relative inline-block">
    <button id="dcp-delete-btn"
        class="flex items-center gap-2 px-3 py-2 text-sm
               bg-red-600 text-white rounded-md
               hover:bg-red-700 transition">
        🗑 Delete
    </button>

    <div id="dcp-confirm"
        class="hidden absolute right-0 mt-2 w-56 bg-white
               border border-gray-200 rounded-lg shadow-lg p-4 z-50">
        <p class="text-sm text-gray-700 mb-3">
            This will move the post to trash.
        </p>

        <div class="flex justify-end gap-2">
            <button id="dcp-cancel"
                class="px-3 py-1 text-sm border rounded hover:bg-gray-100">
                Cancel
            </button>

            <button id="dcp-confirm-delete"
                class="px-3 py-1 text-sm bg-red-600 text-white rounded
                       hover:bg-red-700 disabled:opacity-50">
                Confirm
            </button>
        </div>
    </div>
</div>
HTML;
});
add_action('wp_ajax_dcp_delete_post', function () {
    check_ajax_referer('dcp_delete', 'nonce');

    $post_id = (int) $_POST['post_id'];
    $post = get_post($post_id);

    if (!$post) {
        wp_send_json_error('Invalid post');
    }

    $user_id = get_current_user_id();

    if (
        (int) $post->post_author !== $user_id &&
        !current_user_can('delete_others_posts')
    ) {
        wp_send_json_error('Unauthorized');
    }

    // Soft delete → move to trash
    wp_trash_post($post_id);

    wp_send_json_success();
});
